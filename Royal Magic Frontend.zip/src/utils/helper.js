export function throwIfExists(err) {
    if(err) {
        throw err;
    }
}